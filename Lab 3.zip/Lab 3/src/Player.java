public class Player {

    protected String name;
    protected double currentAmount;

    // Getter for name
    public String getName() {
        return name;
    }

    // Setter for name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for currentAmount
    public double getCurrentAmount() {
        return currentAmount;
    }

    // Setter for currentAmount
    public void setCurrentAmount(double currentAmount) {
        this.currentAmount = currentAmount;
    }

    // Print player info
    public void printInfo() {
        System.out.println("User Name: " + name);
        System.out.println("Current Amount: $" + currentAmount);
    }
}