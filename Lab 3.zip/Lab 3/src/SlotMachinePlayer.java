public class SlotMachinePlayer extends Player {

    private double totalDeposited;
    private int numOfSpin;
    private int numOfSpinWon;

    // Getter and Setter for totalDeposited
    public double getTotalDeposited() {
        return totalDeposited;
    }

    public void setTotalDeposited(double totalDeposited) {
        this.totalDeposited = totalDeposited;
    }

    // Getter and Setter for numOfSpin
    public int getNumOfSpin() {
        return numOfSpin;
    }

    public void setNumOfSpin(int numOfSpin) {
        this.numOfSpin = numOfSpin;
    }

    // Getter and Setter for numOfSpinWon
    public int getNumOfSpinWon() {
        return numOfSpinWon;
    }

    public void setNumOfSpinWon(int numOfSpinWon) {
        this.numOfSpinWon = numOfSpinWon;
    }

    // Override printInfo()
    @Override
    public void printInfo() {

        System.out.println("User Name: " + name);
        System.out.println("Current Amount: $" + currentAmount);
        System.out.println("Total Deposited: $" + totalDeposited);
        System.out.println("Total Spins : " + numOfSpin);
        System.out.println("Total Spins Won: " + numOfSpinWon);
    }
}