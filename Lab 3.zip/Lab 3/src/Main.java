/*
          Name: Alexander Young
          Email: alexyoungodin@gmail.com
          Team Members: 
          Collaboration with (outside of team members):
          References:

*/

import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        Random rand = new Random();

        SlotMachinePlayer player = new SlotMachinePlayer();

        System.out.print("Enter User name: ");
        player.setName(input.nextLine());

        int choice;

        do {

            System.out.println("\n---- SLOT MACHINE MENU ----");
            System.out.println("1. Deposit Money");
            System.out.println("2. Spin");
            System.out.println("3. Show User Info");
            System.out.println("4. Exit");
            System.out.print("Choose option: ");

            choice = input.nextInt();

            switch (choice) {

                case 1:
                    System.out.print("Enter Your deposit amount: ");
                    double deposit = input.nextDouble();

                    player.setCurrentAmount(player.getCurrentAmount() + deposit);
                    player.setTotalDeposited(player.getTotalDeposited() + deposit);

                    break;

                case 2:

                    System.out.print("Enter bet amount: ");
                    double bet = input.nextDouble();

                    if (bet > player.getCurrentAmount()) {
                        System.out.println("Not enough money");
                        break;
                    }

                    player.setCurrentAmount(player.getCurrentAmount() - bet);
                    player.setNumOfSpin(player.getNumOfSpin() + 1);

                    int n1 = rand.nextInt(20) + 1;
                    int n2 = rand.nextInt(20) + 1;
                    int n3 = rand.nextInt(20) + 1;

                    System.out.println("Spin results: " + n1 + " | " + n2 + " | " + n3);

                    // Jackpot
                    if (n1 == 7 && n2 == 7 && n3 == 7) {

                        double win = bet * 10;
                        player.setCurrentAmount(player.getCurrentAmount() + win);
                        player.setNumOfSpinWon(player.getNumOfSpinWon() + 1);

                        System.out.println("JACKPOT! You won $" + win);

                    }

                    // Regular win
                    else if (n1 == n2 && n2 == n3) {

                        double win = bet * 3;
                        player.setCurrentAmount(player.getCurrentAmount() + win);
                        player.setNumOfSpinWon(player.getNumOfSpinWon() + 1);

                        System.out.println("You won $" + win);

                    } else {

                        System.out.println("You lost this spin.");

                    }

                    break;

                case 3:
                    player.printInfo();
                    break;

                case 4:
                    System.out.println("Thanks for playing!");
                    break;

                default:
                    System.out.println("Invalid option.");

            }

        } while (choice != 4);

        input.close();
    }
}